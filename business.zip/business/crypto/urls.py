from django.urls import path
from .views import CryptoDataAPIView

urlpatterns = [
    path('crypto/', CryptoDataAPIView.as_view(), name='crypto-data'),
]
