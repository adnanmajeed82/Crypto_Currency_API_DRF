from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import requests
from .models import CryptoCurrency  # Optional: If you're storing data
from .serializers import CryptoCurrencySerializer  # Optional: If you're storing data

class CryptoDataAPIView(APIView):
    def get(self, request, format=None):
        try:
            # Fetch data from a cryptocurrency API (e.g., CoinGecko)
            response = requests.get('https://api.coingecko.com/api/v3/coins/markets', params={
                'vs_currency': 'usd',
                'order': 'market_cap_desc',
                'per_page': 10,
                'page': 1,
                'sparkline': False
            })

            # Check if the request was successful
            if response.status_code == 200:
                crypto_data = response.json()

                # Optionally: Save data to the database
                for item in crypto_data:
                    CryptoCurrency.objects.update_or_create(
                        symbol=item['symbol'],
                        defaults={
                            'name': item['name'],
                            'price': item['current_price'],
                            'change_24h': item['price_change_percentage_24h'],
                            'market_cap': item['market_cap'],
                        }
                    )

                # Optionally: Serialize data if saved in the database
                if CryptoCurrency.objects.exists():
                    saved_data = CryptoCurrency.objects.all()
                    serializer = CryptoCurrencySerializer(saved_data, many=True)
                    return Response(serializer.data, status=status.HTTP_200_OK)

                return Response(crypto_data, status=status.HTTP_200_OK)

            return Response({'error': 'Unable to fetch data'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
